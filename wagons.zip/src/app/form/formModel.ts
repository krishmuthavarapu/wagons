export class Register {
    constructor(
        public username:string,
        public name: string,
        public password:string,
        public cpassword:string,
        public email: string,
        public number: string,
        public checkbox:boolean
    ){}
}
